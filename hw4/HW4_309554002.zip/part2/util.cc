#include <stdio.h>
#include <stdlib.h>
#include <mpi.h>

#define MASTER 0
#define FROM_MASTER 1
#define FROM_WORKER 2

// Read size of matrix_a and matrix_b (n, m, l) and whole data of matrixes from stdin
//
// n_ptr:     pointer to n
// m_ptr:     pointer to m
// l_ptr:     pointer to l
// a_mat_ptr: pointer to matrix a (a should be a continuous memory space for placing n * m elements of int)
// b_mat_ptr: pointer to matrix b (b should be a continuous memory space for placing m * l elements of int)
void construct_matrices(int *n_ptr, int *m_ptr, int *l_ptr, int **a_mat_ptr, int **b_mat_ptr){
	//printf("In construct_matrics!\n");
	MPI_Status status;
	int rank, size;
	int n, m, l;
	MPI_Comm_size(MPI_COMM_WORLD,&size);
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
	//printf("rank: %d, size: %d\n", rank, size);

	int	numtasks,              /* number of tasks in partition */
		taskid,                /* a task identifier */
		numworkers,            /* number of worker tasks */
		source,                /* task id of message source */
		dest,                  /* task id of message destination */
		mtype,                 /* message type */
		rows,                  /* rows of matrix A sent to each worker */
		averow, extra, offset, /* used to determine rows sent to each worker */
		i, j, k, rc;           /* misc */

	numworkers = size - 1;

	if (rank == 0) {
		scanf("%d %d %d", n_ptr, m_ptr, l_ptr);
	
		n = *n_ptr;
		m = *m_ptr;
		l = *l_ptr;
		*a_mat_ptr = (int *)malloc(n * m * sizeof(int));
		*b_mat_ptr = (int *)malloc(m * l * sizeof(int));
		int i;
		for (i = 0; i < (n*m); i++) {
			scanf("%d", &(*a_mat_ptr)[i]);
		}
		//printf("aaa: %d\n", (*a_mat_ptr)[0]);

		for (i = 0; i < (m*l); i++) {
			scanf("%d", &(*b_mat_ptr)[i]);
		}
			
	}
	
	MPI_Bcast(n_ptr, 1, MPI_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(m_ptr, 1, MPI_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(l_ptr, 1, MPI_INT, 0, MPI_COMM_WORLD);

	n = *n_ptr;
	m = *m_ptr;
	l = *l_ptr;
	
	/*
	if (rank == 0) {
		averow = n / numworkers;
		extra = n % numworkers;
		offset = 0;
		mtype = FROM_MASTER;
		for (dest = 1; dest <= numworkers; dest++) {
			rows = (dest <= extra) ? averow+1 : averow;
			
			MPI_Send(&offset, 1, MPI_INT, dest, mtype, MPI_COMM_WORLD);
			MPI_Send(&rows, 1, MPI_INT, dest, mtype, MPI_COMM_WORLD);
			MPI_Send(&(*a_mat_ptr )[offset*m + 0], rows*m, MPI_INT, dest, mtype, MPI_COMM_WORLD);
			offset = offset + rows;
		}

		mtype = FROM_WORKER;
		for (i=1; i<=numworkers; i++) {
			source = i;
			MPI_Recv(&offset, 1, MPI_INT, source, mtype, MPI_COMM_WORLD, &status);
			MPI_Recv(&rows, 1, MPI_INT, source, mtype, MPI_COMM_WORLD, &status);
			
		}
	}
	else if (rank != 0) {
		*a_mat_ptr = (int *)malloc(averow * m * sizeof(int));
        *b_mat_ptr = (int *)malloc(m * l * sizeof(int));

		mtype = FROM_MASTER;
		MPI_Recv(&offset, 1, MPI_INT, 0, mtype, MPI_COMM_WORLD, &status);
		MPI_Recv(&rows, 1, MPI_INT, 0, mtype, MPI_COMM_WORLD, &status);
		MPI_Recv(&(*a_mat_ptr), rows*m, MPI_INT, 0, mtype, MPI_COMM_WORLD, &status);
		//MPI_Recv(&b, NCA*NCB, MPI_DOUBLE, MASTER, mtype, MPI_COMM_WORLD, &status);

		mtype = FROM_WORKER;
		MPI_Send(&offset, 1, MPI_INT, 0, mtype, MPI_COMM_WORLD);
		MPI_Send(&rows, 1, MPI_INT, 0, mtype, MPI_COMM_WORLD);
	}*/

	if (rank != 0) {
		*a_mat_ptr = (int *)malloc(n * m * sizeof(int));
		*b_mat_ptr = (int *)malloc(m * l * sizeof(int));
	}

	MPI_Bcast(&(*b_mat_ptr)[0], m*l, MPI_INT, 0, MPI_COMM_WORLD);

	/*
	if (rank == 0) {
		// send matrix A
		for (i = 1; i < size; i++){
			MPI_Send(&matrixA[partrow * m * i], partrow*m, MPI_INT, i, 0, MPI_COMM_WORLD);
		}
	}*/
	MPI_Bcast(&(*a_mat_ptr)[0], n*m, MPI_INT, 0, MPI_COMM_WORLD);

}


// Just matrix multiplication (your should output the result in this function)
//
// n:     row number of matrix a
// m:     col number of matrix a / row number of matrix b
// l:     col number of matrix b
// a_mat: a continuous memory placing n * m elements of int
// b_mat: a continuous memory placing m * l elements of int
void matrix_multiply(const int n, const int m, const int l, const int *a_mat, const int *b_mat){
	//printf("In matrix_multiply!\n");
	int rank, size;

	MPI_Comm_size(MPI_COMM_WORLD, &size);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	printf("(rank %d) n: %d, m: %d, l: %d\n", rank, n, m, l);
	printf("(rank %d) a_mat[0]: %d\n", rank, a_mat[0]);

	int	numtasks,              /* number of tasks in partition */
		taskid,                /* a task identifier */
		numworkers,            /* number of worker tasks */
		source,                /* task id of message source */
		dest,                  /* task id of message destination */
		mtype,                 /* message type */
		rows,                  /* rows of matrix A sent to each worker */
		averow, extra, offset, /* used to determine rows sent to each worker */
		i, j, k, rc;           /* misc */

	MPI_Status status;

	int *c = (int *)malloc(n * l * sizeof(int));

	numworkers = size - 1;

	if (rank == 0) {
		averow = n / numworkers;
		extra = n % numworkers;
		offset = 0;

		
		mtype = FROM_MASTER;
		for (dest = 1; dest <= numworkers; dest++) {
			rows = (dest <= extra) ? averow+1 : averow;

			MPI_Send(&offset, 1, MPI_INT, dest, mtype, MPI_COMM_WORLD);
			MPI_Send(&rows, 1, MPI_INT, dest, mtype, MPI_COMM_WORLD);
			offset = offset + rows;
		}

		mtype = FROM_WORKER;
		for (i = 1; i <= numworkers; i++) {
			source = i;
			MPI_Recv(&offset, 1, MPI_INT, source, mtype, MPI_COMM_WORLD, &status);
			MPI_Recv(&rows, 1, MPI_INT, source, mtype, MPI_COMM_WORLD, &status);
			MPI_Recv(&c[offset*l + 0], rows*l, MPI_INT, source, mtype, MPI_COMM_WORLD, &status);
		}	
	

/*	
	for(i = 0; i < n; i++) {
		for(j = 0; j < m; j++) {
			printf("rank: %d, %d ", rank, a_mat[i*m + j]);
		}
		printf("\n");
	}


	for(i = 0; i < m; i++) {
		for(j = 0; j < l; j++) {
			printf("rank: %d, %d ", rank, b_mat[i*l + j]);
		}
	}

		for (k = 0; i < l; k++) {
			for (i = 0; i < n; i++) {
				c[i*l + k] =  0;
				for (j = 0; j < m; j++) {
					c[i*l + k] = c[i*l +k] + a_mat[i*m +j] * b_mat[j*l + k];
				}
			}
		}
*/
		for(i = 0; i < n; i++) {
			for(j = 0; j < l; j++) {
				printf("%d ", c[i*l + j]);
			}
			printf("\n");
		}
	} else if (rank != 0) {
		mtype = FROM_MASTER;
		MPI_Recv(&offset, 1, MPI_INT, MASTER, mtype, MPI_COMM_WORLD, &status);
		MPI_Recv(&rows, 1, MPI_INT, MASTER, mtype, MPI_COMM_WORLD, &status);

		for (k=0; k<l; k++)
			for (i=0; i<rows; i++) {
				c[i*l + k] = 0;
				for (j=0; j<n; j++)
					c[i*l + k] = c[i*l + k] + a_mat[i*m + j] * b_mat[j*l + k];
			}
		mtype = FROM_WORKER;
		MPI_Send(&offset, 1, MPI_INT, MASTER, mtype, MPI_COMM_WORLD);
		MPI_Send(&rows, 1, MPI_INT, MASTER, mtype, MPI_COMM_WORLD);
		MPI_Send(&c, rows*l, MPI_INT, MASTER, mtype, MPI_COMM_WORLD);
	}

}


// Remember to release your allocated memory
void destruct_matrices(int *a_mat, int *b_mat){
	//printf("In destruct_matrices!\n");
	free(a_mat);
	free(b_mat);
}
